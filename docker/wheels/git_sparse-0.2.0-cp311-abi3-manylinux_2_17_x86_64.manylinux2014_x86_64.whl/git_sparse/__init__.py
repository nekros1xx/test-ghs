"""git_sparse — in-memory "sparse checkout".

Read files matching git-style glob patterns straight out of a repository's
object database into memory, without ever writing them to disk::

    files = git_sparse.repo("https://github.com/owner/repo").sparse_checkout(
        ".github/workflows/*.yml", ".github/workflows/*.yaml"
    )
    for f in files:
        print(f.name, f.read())

Remote repositories are cloned bare with ``--filter=blob:none`` (partial
clone: commits and trees only), so only the blobs that actually match your
patterns are ever downloaded.
"""

import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import weakref

from git_sparse._core import GitError, MissingBlobsError
from git_sparse._core import Repo as _CoreRepo

__all__ = ["repo", "Repo", "GitError", "MissingBlobsError"]

_URL_RE = re.compile(r"^[a-z][a-z0-9+.-]*://", re.IGNORECASE)
_SCP_RE = re.compile(r"^[^/\s]+@[^/\s]+:")


def _is_url(spec):
    return bool(_URL_RE.match(spec) or _SCP_RE.match(spec))


def _clone_dir(base):
    if base is None:
        # RAM-backed tmpfs when available, so pack data never hits disk.
        base = "/dev/shm" if os.path.isdir("/dev/shm") else None
    return tempfile.mkdtemp(prefix="git_sparse-", dir=base)


def _force_remove(func, path, _exc):
    # git pack files are read-only; on Windows that makes rmtree fail
    os.chmod(path, stat.S_IWRITE)
    func(path)


def _rmtree_force(path):
    try:
        if sys.version_info >= (3, 12):
            shutil.rmtree(path, onexc=_force_remove)
        else:
            shutil.rmtree(path, onerror=_force_remove)
    except OSError:
        pass


def _git(*argv, **kwargs):
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    try:
        return subprocess.run(
            ["git", *argv], check=True, capture_output=True, env=env, **kwargs
        )
    except FileNotFoundError:
        raise GitError("the git CLI is required but was not found on PATH")
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode(errors="replace") if e.stderr else ""
        raise GitError(f"git {argv[0]} failed: {stderr.strip()}") from None


class Repo:
    """A git repository opened for in-memory reads.

    For remote URLs the repository is cloned bare (no working tree) into a
    temporary directory — under /dev/shm (RAM) when available — which is
    deleted automatically when this object is garbage collected.

    The clone is a *partial clone* (``--filter=blob:none``): only commits
    and trees are transferred up front, and file contents are fetched
    lazily, in one batch, for exactly the paths your patterns match.
    (Servers without filter support simply send everything, with a warning
    from git.)
    """

    def __init__(self, spec, *, depth=1, tmpdir=None):
        self._finalizer = None
        if _is_url(spec):
            path = _clone_dir(tmpdir)
            try:
                cmd = ["clone", "--quiet", "--bare", "--single-branch",
                       "--filter=blob:none"]
                if depth:
                    cmd += ["--depth", str(depth)]
                _git(*cmd, spec, path)
                self._core = _CoreRepo(path)
                self._gitdir = path
            except BaseException:
                _rmtree_force(path)
                raise
            self._finalizer = weakref.finalize(self, _rmtree_force, path)
        else:
            self._core = _CoreRepo(spec)
            self._gitdir = spec

    def _fetch_blobs(self, oids):
        """Fetch missing blobs from origin in one round trip.

        Same invocation git itself uses for promisor lazy fetches: noop
        negotiation, --filter so the connectivity check tolerates the other
        objects we still don't have. Needs uploadpack.allowAnySHA1InWant on
        the server (every partial-clone-capable host enables it).
        """
        payload = "\n".join(oids) + "\n"
        try:
            _git("-C", self._gitdir, "-c", "fetch.negotiationAlgorithm=noop",
                 "fetch", "--quiet", "--no-tags", "--no-write-fetch-head",
                 "--recurse-submodules=no", "--filter=blob:none", "--stdin",
                 "origin", input=payload, text=True)
            return
        except GitError:
            pass
        # Fallback: reading the objects triggers git's promisor-remote lazy
        # fetching, one object at a time.
        _git("-C", self._gitdir, "cat-file", "--batch-check=%(objectsize)",
             input=payload, text=True)

    def sparse_checkout(self, *patterns, ref="HEAD", strict=False,
                        known_files=None):
        """Return ``[{"hash": <hex oid>, "file": <SparseFile>}, ...]`` for
        every blob at `ref` whose path matches any of the git-style glob
        patterns.

        `known_files` is an iterable of hashes from previous results; blobs
        whose hash is in it are skipped entirely — never loaded, never
        fetched over the network — so only new or changed files are returned.
        """
        if self._core is None:
            raise GitError("repository is closed")
        if known_files is not None:
            known_files = [str(h) for h in known_files]
        try:
            files = self._core.sparse_checkout(
                *patterns, ref=ref, strict=strict, known_files=known_files
            )
        except MissingBlobsError as e:
            self._fetch_blobs(e.oids)
            files = self._core.sparse_checkout(
                *patterns, ref=ref, strict=strict, known_files=known_files
            )
        return [{"hash": f.id, "file": f} for f in files]

    def close(self):
        """Drop the repository and delete its clone directory, if any."""
        self._core = None
        if self._finalizer is not None:
            self._finalizer()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def repo(spec, *, depth=1, tmpdir=None):
    """Open a local repository path or clone a remote URL for in-memory reads.

    depth applies to URL clones only: 1 (default) fetches just the tip
    commit's history; 0 fetches full history (needed for ref= other than
    the default branch tip).
    """
    return Repo(spec, depth=depth, tmpdir=tmpdir)
